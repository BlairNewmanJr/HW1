module load mkl

